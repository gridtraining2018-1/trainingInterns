﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    public class Program
    {
        int firstNum, secondNum;
        public Program() { }
        public Program(int firstNum, int secondNum)
        {
            this.firstNum = firstNum;
            this.secondNum = secondNum;
        }
        public void swap()
        {

            firstNum = firstNum + secondNum;
            secondNum = firstNum - secondNum;
            firstNum = firstNum - secondNum;


        }
        public void swap(ref int firstNum, ref int secondNum)
        {


            firstNum = firstNum + secondNum;
            secondNum = firstNum - secondNum;
            firstNum = firstNum - secondNum;
            Console.WriteLine("After swapping");
            Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
            Console.ReadKey();


        }
        public virtual void Display()
        {
            Console.WriteLine("After swapping");
            Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
            Console.ReadKey();
        }
    }
    public class assesending : Program
    {
        int firstNum, secondNum;
        public assesending(int firstNum, int secondNum)
        {


            if (firstNum > secondNum) { swap(ref firstNum, ref secondNum);
                Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
                Console.ReadKey(); }
            this.firstNum = firstNum;
            this.secondNum = secondNum;
        }
        public override void Display()
        {
            Console.WriteLine("accending");
            Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
            Console.ReadKey();
        }

    }
    public class dssesending : Program
    {
        int firstNum, secondNum;
        public dssesending(int firstNum, int secondNum)
        {


            if (firstNum < secondNum)
            {
                swap(ref firstNum, ref secondNum);
                Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
                Console.ReadKey();
            }
            this.firstNum = firstNum;
            this.secondNum = secondNum;
        }
        public override void Display()
        {
            Console.WriteLine("accending");
            Console.WriteLine("firstnum={0} secondNum={1}", firstNum, secondNum);
            Console.ReadKey();
        }

    }
    class check : assesending
    { public check(int a, int b) : base(a, b) { }

    }
    interface printmsg{
        void getresult();
    }

    class access:printmsg
    {
      static void Main(String[] args)
        {
            Program obj = new assesending(10,5);
            Program obj1 = new Program(11, 53);
            obj.Display();
            obj1.Display();
            access obj2 = new access();
            obj2.getresult();
           
           
        }

        public void getresult()
        {
            Console.WriteLine("we have interface");
        }
    }
}
