﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication12
{
  class Program1
    {
        int num;
       public  virtual void evenOdd()
        {
            if (num % 2 == 0)
            {
                Console.WriteLine("Number is Even1");
            }
            else
            {
                Console.WriteLine("Number is Odd1");
            }

        }
    }
    

    
    class Program:Program1
    {
        int number, number1, number2;
        Program(int number)
        {
            this.number = number;
        }

        Program(int number1, int number2)
        {
            this.number1 = number1;
            this.number2 = number2;
        }

       public  override void evenOdd()
        {
            if (number % 2 == 0)
            {
                Console.WriteLine("Number is Even2");
            }
            else
            {
                Console.WriteLine("Number is Odd2");
            }
            System.int[] sadf = new int[];

            System.Double ak = new double();

            DataTable df = new DataTable();

        }
        void swap ()
        {
            number1 = number1 + number2;
            number2 = number1 - number2;
            number1 = number1 - number2;
            Console.WriteLine(number1);
            Console.WriteLine(number2);

        }

        void swap(int a,int b)
        {
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine(a);
            Console.WriteLine(b);

        }
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the Nunber :");
            int number = Convert.ToInt16(Console.ReadLine());
            //Program objProgram = new Program(number);
            Program1 objProgram3 = new Program1();
            Program objProgram1 = new Program(2,3);
            objProgram1.evenOdd();
            objProgram3.evenOdd();
            objProgram1.swap();
            objProgram1.swap(2,9);

            Console.ReadKey();
        }
    }
}