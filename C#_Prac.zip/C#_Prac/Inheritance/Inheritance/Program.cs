﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Prog
    {
        /// <summary>
        /// 
        /// </summary>
        public virtual void display()
        {
            Console.WriteLine("Prog");
        }

        public void display2()
        {
            Console.WriteLine("display");
        }
    }

    class Prog1 : Prog
    {
        public override void display()
        {
            Console.WriteLine("Prog1");
        }
    }
    class Program : Prog1
    {
        static void Main(string[] args)
        {
            Program obj2 = new Program();
            obj2.display();
            //obj2.display();
            //obj3.display();
            obj2.display2();
            Console.ReadKey();

        }
    }
}
