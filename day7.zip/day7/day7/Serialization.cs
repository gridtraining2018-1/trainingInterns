﻿/*using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
[Serializable]
class Student
{
    public int rollno;
    public string name;
    public Student(int rollno, string name)
    {
        this.rollno = rollno;
        this.name = name;
    }
}
public class SerializeExample
{
    public static void Main(string[] args)

    {
        try
        {


            FileStream stream = new FileStream("D:\\lle.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            Student s = new Student(101, "shubham");
            formatter.Serialize(stream, s);
            FileStream stream1 = new FileStream("D:\\eee.txt", FileMode.OpenOrCreate);

            Student s1 = (Student)formatter.Deserialize(stream1);
            Console.Write("name " + s1.name);

        }

        catch (Exception e)
        {
            Console.WriteLine(e);
        }
        finally
        {

        }





    }
}*/