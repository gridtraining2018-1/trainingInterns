﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day7
{


    class student
    {
        public int rollno { get; set; }
        public string name { get; set; }
        public int age { get; set; }

    }
    public class indexer
    {
        private List<student> students;
        public indexer()
        {
            students = new List<student>();
            students.Add(new student { rollno = 106, name = "Shubham", age = 25  });
            students.Add(new student { rollno = 105, name = "rahul", age = 27 });
            students.Add(new student { rollno = 107, name = "himasnhu", age = 28 });
            students.Add(new student { rollno = 107, name = "himasnhu", age = 28 });
            students.Add(new student { rollno = 105, name = "rahul", age = 27 });
            students.Add(new student { rollno = 107, name = "himasnhu", age = 28 });




        }

        public string this[int rollno]
        {
          
            get
            {

                return students.FirstOrDefault(student => student.rollno == rollno).name;

            }
            set
            {
                students.FirstOrDefault(student => student.rollno == rollno).name = value;

            }
        }
       
        public string this [int age,string name]
        {
            get
            {

                return students.Count(student => student.age == age).ToString();
            }
            set
            {
                foreach(student student in students)
                {
                    if(student.age <age)
                    {
                        student.name = value;
                    }
                }
            }
        }

        public int this[string name ]
        {

            get
            {

                return students.FirstOrDefault(student => student.name == name).rollno;

            }
           
        }

    }
    

    public class test
    {
        static void Main(string[] args)
        {
        indexer index = new indexer();
            student student = new student();
            Console.WriteLine("name of student before updating:" + index[106]);
            index[106] = "said";
            Console.WriteLine("name of student after  updating:" + index[106]);
            //count
            Console.WriteLine("count according to  age:" + index[28,""]);
            index[28, ""] = "name changed";
            Console.WriteLine("-------------------------------------------------------------------");


            Console.WriteLine(" after updating:" + index[106]);

            Console.WriteLine("-------------------------------------------------------------------");
            Console.WriteLine(" after updating whose rollno is updated name:" + index["name changed"]);


            Console.ReadKey();
        }
    }
    }
    */