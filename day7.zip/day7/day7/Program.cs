﻿   /* using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day7
{


    abstract class day7
    {
  public  abstract  void eat();
    }

    class Program: day7
    {
     public override void  eat()
        {
            Console.WriteLine("eating");

        }
        //static void Main(string[] args)
        //{
        //     day7 day = new Program();
        //    day.eat();
        //    Console.ReadKey();
       

        //}
    }
}
*/
