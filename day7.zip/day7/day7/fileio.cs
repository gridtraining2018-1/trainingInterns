﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace day7
{
    class fileio
    {


    

        static void Main(String[] args)
        {
            try
            {
                FileStream f = new FileStream("D:\\output11.txt", FileMode.OpenOrCreate);
                StreamWriter s = new StreamWriter(f);
                
                s.WriteLine("hello c#");
                
                StreamReader reader = new StreamReader(f);
                string hello = reader.ReadLine();
                Console.WriteLine(hello);
                s.Close();
                reader.Close();
                f.Close();
                Console.WriteLine("File created successfully...");
                Console.ReadKey();
            }

            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {

            }


        }
    }
}
