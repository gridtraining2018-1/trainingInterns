﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;

namespace day7
{
    public abstract class abstractExample
    {
       private int  a;
        public abstract void display() ;
    }
    class Program:abstractExample
    {
        static void Main(string[] args)
        {
            new Program().display();
            new Program().TryExample();
            Type type = typeof(Program);
            bool check = type.IsClass;
            Console.Write(type);
        }

        public override void display()
        {
            Console.WriteLine("Its abstract class method");
            Console.ReadKey();
            FileStream file = new FileStream("text.txt", FileMode.Create);
            StreamReader fl;

           
            StreamWriter f= new StreamWriter(file);
            f.Write("tfytgkhgbcdhgsjha");
            f.Flush();
           
            fl = new StreamReader(file);

            string aa = fl.ReadLine();
            aa = fl.ReadLine();
            Console.WriteLine(aa);
            Console.ReadKey();
            f.Close();
           
            fl.Close();
            StreamWriter fn = new StreamWriter("text.txt", append: true);
            fn.Write("\n  append the data");
            fn.Close();
            file.Close();


        }
        public void TryExample()
        {
            int firstNum = 0,secondNum=12;
            #region "This is try catch region"
            try
            {
                firstNum = secondNum / firstNum;
            }
            catch
            {
                try
                {
                    throw new Exception("this is divide exception");
                } 
                catch(Exception e)
                {

                    Console.WriteLine(e);
                    Console.ReadKey();

                } 
            }
            #endregion
        }
    }
}
