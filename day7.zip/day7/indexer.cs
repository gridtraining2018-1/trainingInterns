using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace day7
{


    class student
    {
        public int rollno { get; set; }
        public string name { get; set; }
        public int age { get; set; }
    }
    public class indexer
    {
        private List<student> students;
        public indexer()
        {
            students = new List<student>();
            students.Add(new student { rollno = 106, name = "Shubham", age = 25 });
            students.Add(new student { rollno = 105, name = "rahul", age = 27 });
            students.Add(new student { rollno = 107, name = "himasnhu", age = 28 });


        }
        public string this[int rollno]
        {
            get
            {
                return students.FirstOrDefault(student => student.rollno == rollno).name;
            }
            set
            {
                students.FirstOrDefault(student => student.rollno == rollno).name = value;

            }
        }
    }
    

    public class test
    {
        static void Main(string[] args)
        {
        indexer index = new indexer();
            Console.WriteLine("name of student before updating:" + index[106]);
           index[106] = "Vinay";
            Console.WriteLine("name of student after  updating:" + index[106]);
            Console.ReadKey();
        }
    }
    }
